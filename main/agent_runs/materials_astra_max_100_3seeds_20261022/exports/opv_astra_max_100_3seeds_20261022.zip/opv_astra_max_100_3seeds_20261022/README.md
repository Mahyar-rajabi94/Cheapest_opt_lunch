# OPV pool: finalized Astra max results

Three independent fresh Codex CLI campaigns, seeds 0/1/2, GPT-6 Astra with max reasoning, exactly 100 evaluations each. Each passed 28 native isolation checks and the final trace/journal/data-replay audits. All three found the pool maximum PCE, 15.707252%, at calls 52, 98 and 77 respectively. The agent did not receive the optimum or baseline results.

## Start here

- `figures/opv_pool/00_complete_comparison.png`: complete comparison, including mean curves, sample standard deviations, final performance and all three decision timelines.
- The same figure is available as PDF and SVG; `_log` versions use a logarithmic regret axis.
- `seed_0_decision_timeline`, `seed_1_decision_timeline`, `seed_2_decision_timeline`: detailed individual decisions, in PNG/PDF/SVG.
- `01_final_regret`, `02_convergence`, `03_decision_timeline`: additional seed-level figures.
- `summary.csv`: final outcomes. `figures/opv_pool/comparison_curves.csv`: all plotted mean/SD values.

## Comparison convention

All methods use the first 100 objective evaluations, including initialization. Agent curves are arithmetic means across three seeds; stochastic baselines use ten seeds; BOBYQA, L-BFGS-B and Nelder-Mead each have one supplied deterministic run. Bands/error bars are sample standard deviations (ddof=1), not standard errors or confidence intervals. No variability is estimated for single-seed methods. Lower band endpoints are clipped at zero; logarithmic figures draw zero at 1e-8. Regret is maximum measured pool PCE minus best observed PCE.

Every supplied baseline row was checked against the registered pool, including the nearest-untested selection mapping, candidate ID, measured label, and running best. The DE and uniform-box-random traces coincide through 100 calls and are retained as supplied. Uniform pool sampling samples devices uniformly; uniform box sampling proposes coordinates and uses the nearest-untested mapping.

The dataset has 526 devices and 11 features. The private evaluator maps every proposed point to the nearest untested device. Repeated input coordinates can therefore return different devices. The reported best device is not a promise that repeating its query coordinates returns its value again.

## Evidence

`runs/opv_pool/seed_<n>/` contains each original trace, scored trace, exact decision snapshots and text, generated Python code, fresh-context CLI event log, source/runtime manifest, and isolation/integrity/offline audits. Device identities and full-pool scores are trusted post-run additions and were not sent to the agents. `baselines/opv/opv_pool_pce_d11/` contains all 73 supplied baseline runs. `sha256.json` hashes the export.

Agent source commit: cbe3886f40e2eeffa002d353188d8ca57a9143cf.
OPV baseline branch commit: ef1be572e038487dc37a5bd098e5d5d25fab8fb3.
Repository: https://github.com/Mahyar-rajabi94/Cheapest_opt_lunch

To regenerate figures, extract this directory inside a clone of the repository and run its `report.py --render-only --task opv_pool`, followed by `comparison_report.py --task opv_pool`, using `.agent-venv/bin/python`. Model generation is not deterministic even when the campaign seed is fixed. These are the requested detailed arithmetic-mean/SD reports; the repository's separate paper-style geometric-mean/SE convention is not used here.
