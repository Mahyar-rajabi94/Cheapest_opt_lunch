# MOF results for structure visualization

Three completed Astra max campaigns, seeds 0–2, with 100 paid evaluations each including initialization. These runs selected existing rows from a fixed 1,000-MOF pool; they did not generate new crystal structures.

## Best candidate from each run

| Seed | Material ID | Raw score (maximize) | Pool rank | First found at evaluation | Pool index (zero-based) |
| --- | --- | ---: | ---: | ---: | ---: |
| 0 | SEHTEF | 9.2928301557 | 1 | 65 | 561 |
| 1 | SEHTEF | 9.2928301557 | 1 | 54 | 561 |
| 2 | AJOTEY | 8.8133131168 | 3 | 24 | 399 |

## To render the optimized MOF

Obtain the original crystal structure files corresponding to **SEHTEF** and **AJOTEY** from the dataset provider. Match the exact source structure variant used for these rows (including any cleaning, disorder handling or solvent removal). The supplied task archive contains no CIF files or atomic coordinates; this export therefore does not contain a renderable crystal structure. The anonymous x0–x192 descriptors do not provide atom positions, lattice vectors or an unambiguous reconstruction of the MOF. No structural identity beyond the supplied material ID has been independently verified.

## Files

- `structure_lookup.csv` and `material_ids.txt`: the two unique best IDs to match to original structure files.
- `best_per_seed.csv`: three best observations, evaluation numbers, exact pool indices, scores and all 193 source features.
- `best_candidates_with_features.csv`: two unique best candidates, with the seeds that selected them and all features.
- `all_evaluations.csv`: all 300 evaluations with material IDs, scores, ranks, optimizer labels and incumbent progression.
- `all_evaluations_with_features.csv`: the same 300 observations with all 193 source feature columns.
- `runs/seed_*/`: original traces, full decision logs, agent-created code, CLI events and isolation/integrity evidence.
- `figures/`: final mean/SD baseline comparison and individual seed/timeline figures in PNG, PDF and SVG, plus plotted curve data.
- `results.json`, `provenance.json`, `sha256.json`: selected results, source/validation details and file hashes.

## Interpretation and indexing

`raw_score_maximize` is the original y and higher is better. `objective_y_minimize` is its negative. The supplied contract does not define the physical meaning or units of y, nor names/units for x0–x192; do not assign an unverified property or unit.

`candidate_index_0based` identifies a row in the exact supplied 1,000-row CSV. `source_csv_line_1based` includes the header, so it equals the zero-based index plus 2. `evaluation` is one-based within a seed. Source descriptor values are preserved from the CSV, not transformed optimizer coordinates. `pool_rank_descending` is 1 + the number of strictly higher-scoring rows; tied scores share a rank.

Material IDs and full-pool ranks were joined only in trusted post-run reporting. They were not exposed to the optimizing agents. Every exported observation was verified against its source row, including all 193 features. Seed 1 is the fresh replacement for the service-interrupted attempt; the interrupted attempt is excluded.
